# Unreceived

## Positioning

An interrupted signal field about the distance between arrival and reception.

## Statement printed on the garment

**Arrival never guaranteed reception.**

The statement is typeset after image generation with a real house font at a measured physical
size; it is not model-generated lettering.

## Meaning

Physical arrival and actual understanding are different events.

## Customer identity

For analogue technology collectors who prefer quiet conceptual graphics.

## Design story

The demand signal `satellites` is translated into **Unreceived**, not copied
as a headline. The design begins with a transmission can arrive without producing a complete reception and transforms that evidence once
through **attenuate**. The result is one signal body loses its terminal fragment across an active gap.

## Why the artwork is off-centre

The asymmetric placement is intentional: the material body enters from low-right; its interruption points into the opposing empty field without creating a counterweight.
The empty garment field is part of the meaning, not unused space. This explanation belongs to the
product description; it is never printed on the garment.

## Production notes

- Preserve the supplied placement canvas; never auto-centre the visible artwork.
- The printed statement must stay attached to the signature interruption.
- Use the supplied print file at the stated size and resolution; do not rebuild the typography.
- Order a physical sample before publishing and inspect text size, colour separation, texture and hand feel.

## Backend keyword seed

satellites, Unreceived, Unreceived
