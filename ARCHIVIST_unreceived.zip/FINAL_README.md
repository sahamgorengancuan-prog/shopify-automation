# ARCHIVIST — approved delivery

Product: **Unreceived**
Statement printed on garment: **Arrival never guaranteed reception.**
Market signal: `satellites` → artistic topic **Unreceived**

| file | what it is |
|---|---|
| FINAL_artwork.png | composed artwork with the typeset statement |
| FINAL_print.png | print file at the configured size and DPI |
| FINAL_mockup.png | garment proof |
| FINAL_blueprint.png/.json | the owned asset that conditioned generation |
| FINAL_product_description.md | listing copy, including why the artwork is off-centre |
| placement_spec.json | production placement contract — never auto-centre |
| reference_audit.json | research references and the conditioning policy |
| candidate_ranking.json | every candidate, its measurements and the critic's verdict |

Paid generations used: 0
