# ARCHIVIST HOUSE BRIEF (V9)

**PRODUCT:** Unreceived

**EVIDENCE:** a steel signal mast carrying interrupted receiver traces — a transmission can arrive without producing a complete reception

**ONE MUTATION:** attenuate — one signal body loses its terminal fragment across an active gap

**HERO:** a tapered signal mast split once below its detached terminal head

**SILHOUETTE ARCHETYPE:** tapered vertical structure

**SIGNATURE INTERRUPTION:** one precise receiving gap remains visibly unresolved

**COMPOSITION:** the material body enters from low-right; its interruption points into the opposing empty field without creating a counterweight; hero occupancy 22-38%; quiet space 55-70%

**MATERIAL:** coarse relief waveform with a selective phosphor-like dry edge

**PALETTE:** #DDDCCF, #66746D, #B3573E

**STATEMENT PRINTED ON GARMENT:** Arrival never guaranteed reception.

**STATEMENT LOCKUP:** left-of-interruption

**REFERENCE ROLE CONTRACT:**
- HERO: [offline] photo plate — a steel signal mast carrying interrupted receiver traces museum collection public domain full object (synthetic) — house role contract: HERO
- SUBJECT: [offline] photo plate — a steel signal mast carrying interrupted receiver traces museum collection public domain full object (synthetic) — house role contract: SUBJECT
- TEXTURE: [offline] texture plate — a steel signal mast carrying interrupted receiver traces surface erosion texture macro (synthetic) — house role contract: TEXTURE
- COLOR: [offline] texture plate — a steel signal mast carrying interrupted receiver traces surface erosion texture macro (synthetic) — house role contract: COLOR

**DIFFERENTIATION:** One factual property, one physical mutation, one displaced hero, one interruption, and one deterministic micro-statement. No fictional archive story.
