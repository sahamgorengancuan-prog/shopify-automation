# ASYMMETRIC ABSTRACT FIELD — Unreceived

- run: `20260824-123055-unreceived`  ·  collection: `nbrunner`  ·  created: 2026-08-24T12:30:55+00:00
- candidates mined: 12 → references kept: 4
- recommended version: **B**

## 1. Niche ladder

| rung | value |
|---|---|
| trend | Unreceived |
| generic | Satellites graphic T-shirt |
| better | Unreceived asymmetric material study |
| niche | a steel signal mast carrying interrupted receiver traces interpreted through attenuate |
| **micro-niche** | **Unreceived — one precise receiving gap remains visibly unresolved** |

Cultural signals:
- Evidence: a transmission can arrive without producing a complete reception
- Tension: arrival is measurable while understanding is not guaranteed
- Mutation: attenuate
- Placement: the material body enters from low-right; its interruption points into the opposing empty field without creating a counterweight
- Printed statement: Arrival never guaranteed reception.

## 2. Search queries

- `A_literal_subject` — a steel signal mast carrying interrupted receiver traces museum collection public domain full object
- `A_literal_subject` — a steel signal mast carrying interrupted receiver traces scientific institution photograph neutral view
- `A_literal_subject` — a steel signal mast carrying interrupted receiver traces physical construction detail museum
- `A_literal_subject` — satellites instrument government research operating environment
- `B_historical_archival` — a steel signal mast carrying interrupted receiver traces cross section museum object public domain
- `B_historical_archival` — a steel signal mast carrying interrupted receiver traces material change scientific archive public domain
- `F_composition` — full abstract composition one off-center mass large negative space black field
- `F_composition` — asymmetric relief print full composition displaced visual weight
- `F_composition` — avant garde graphic full canvas irregular field one interruption
- `F_composition` — experimental poster full composition cropped mass unresolved edge
- `C_visual_language` — attenuate material relief print abstract field
- `C_visual_language` — single-form abstract printmaking decisive silhouette
- `D_texture` — dry ink relief print edge macro neutral
- `D_texture` — a steel signal mast carrying interrupted receiver traces surface erosion texture macro
- `D_texture` — water based screen print ink tooth cotton macro
- `D_texture` — three spot color relief print texture macro

## 3. Selected references

| role | source | score | read |
|---|---|---|---|
| HERO | synthetic | 6.65 | square, monochrome, flat contrast |
| SUBJECT | synthetic | 5.92 | portrait, monochrome, flat contrast |
| TEXTURE | synthetic | 5.30 | landscape, monochrome, flat contrast |
| COLOR | synthetic | 5.45 | portrait, monochrome, flat contrast |

Full board: [board.md](board.md) · [board.html](board.html)

## 4. Art direction

**ASYMMETRIC ABSTRACT FIELD** — Unreceived turns a transmission can arrive without producing a complete reception into one signal body loses its terminal fragment across an active gap.

- SUBJECT: a steel signal mast carrying interrupted receiver traces transformed once by attenuate
- FORM: one substantial irregular material field with one signature interruption; neither icon nor stack
- COMPOSITION: the material body enters from low-right; its interruption points into the opposing empty field without creating a counterweight; visual centre displaced 6-14%; no secondary counterweight
- CAMERA: flat isolated apparel artwork on a 3:4 garment-black generation field
- LIGHT: flat spot-colour separation created by shape, not cinematic lighting
- COLOR: three exact spot colours plus garment black — #DDDCCF, #66746D, #B3573E
- TEXTURE: controlled material tooth inside the hero; clean negative field
- TYPOGRAPHY: reserve one quiet microtype zone beside the interruption; lettering is added after generation
- ERA: contemporary material abstraction
- GRAPHIC LANGUAGE: authored asymmetric field / one physical mutation / precise unresolved edge
- MOOD: quiet, intelligent, tactile, unresolved
- PRINT CHARACTER: three-ink water-based screen print with a memorable outer silhouette

- composition philosophy: the material body enters from low-right; its interruption points into the opposing empty field without creating a counterweight; hero occupancy 22-38%; quiet space 55-70%; asymmetrical but optically intentional
- image treatment: coarse relief waveform with a selective phosphor-like dry edge
- print degradation: selective material wear only; no universal vintage distress

## 5. Directions

| key | lane | trend | niche | unique | apparel | diff | coherence | overall | gate |
|---|---|---|---|---|---|---|---|---|---|
| B | NICHE CULTURAL | 8.3 | 7.4 | 7.2 | 8.8 | 7.7 | 9.2 | **8.03** | pass |

### B — UNRECEIVED

_NICHE CULTURAL_ · one signal body loses its terminal fragment across an active gap; a transmission can arrive without producing a complete reception

- focal point: a tapered signal mast split once below its detached terminal head
- supporting elements:
  - one precise receiving gap remains visibly unresolved
  - one reserved microtype zone

<details><summary>BFL prompt</summary>

```
{
  "priority": "Transform image 1, the owned black-and-white blueprint, into the finished artwork while preserving its exact displaced mass, empty field and interruption.",
  "output": "one original isolated apparel artwork on a perfectly uniform solid #0B0B0C 3:4 canvas",
  "evidence": {
    "real_subject": "a steel signal mast carrying interrupted receiver traces",
    "true_property": "a transmission can arrive without producing a complete reception",
    "subject_must_be_recognisable": "The hero must read unmistakably as a steel signal mast carrying interrupted receiver traces — a tapered vertical structure with a readable head, shaft and base. Someone who has not read this brief must be able to name the object from its silhouette alone. Generic rubble, debris, shards or an unnameable mass is a failure."
  },
  "single_mutation": {
    "verb": "attenuate",
    "metaphor": "one signal body loses its terminal fragment across an active gap"
  },
  "hero": {
    "motif": "a tapered signal mast split once below its detached terminal head",
    "silhouette_archetype": "tapered vertical structure",
    "signature_interruption": "Reserve one clean negative-space notch for one precise receiving gap remains visibly unresolved. The precise interruption line is added once during deterministic finishing.",
    "outer_silhouette": "broad and memorable at 90 pixels; never a thin column, icon, or stack of blocks"
  },
  "composition": {
    "placement": "the material body enters from low-right; its interruption points into the opposing empty field without creating a counterweight",
    "visual_centre_shift": "6-14% away from canvas centre",
    "hero_occupancy": "22-38% of printable field",
    "quiet_space": "55-70%",
    "balance": "intentional asymmetric tension with no mirrored or distant counterweight",
    "reserved_statement_zone": "left-of-interruption"
  },
  "rendering_mode": "linework",
  "material": "coarse relief waveform with a selective phosphor-like dry edge; material tooth exists only inside the hero silhouette",
  "colour": {
    "hero_ink_1": "#DDDCCF",
    "hero_ink_2": "#66746D",
    "single_accent": "#B3573E",
    "uniform_background": "#0B0B0C"
  },
  "context_image_1": "owned structural blueprint only; retain layout and spatial proportions, replace primitive geometry with authored material form that still reads as the named subject",
  "strict_scene_definition": "The canvas contains exactly one substantial displaced hero, one interruption, and clean uniform black space. All texture is clipped inside the hero. The surrounding background is a single flat colour with no fabric, paper, grain, frame, border, labels, symbols or lettering.",
  "lettering_stage": "The generation contains artwork only. The statement is typeset later by code.",
  "print": "three flat water-based ink shapes with minimum 1pt features and decisive thumbnail contrast",
  "avoid": [
    "mirror symmetry",
    "centered badge",
    "crest",
    "archive page",
    "document grid",
    "border",
    "fake labels",
    "fictional institution",
    "fake declassification metadata",
    "pseudo-text",
    "generic vintage emblem",
    "literal trend headline",
    "stacked decorative blocks",
    "generic rubble",
    "unidentifiable debris"
  ]
}
```

</details>

## 6. Warnings

- stopped early: best remaining candidate scored 3.95 below the 4.80 floor
- only 2 references cleared the floor — the art direction will lean on fewer ingredients than intended
- only 1 references cleared the floor — the art direction will lean on fewer ingredients than intended
- stopped early: best remaining candidate scored 3.83 below the 4.80 floor
- house reference firewall rejected 3 stock/watermarked/text-heavy candidates
