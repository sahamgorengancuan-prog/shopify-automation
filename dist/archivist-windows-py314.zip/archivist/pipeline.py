"""The orchestrator — the single entry point every surface calls.

The notebook, the CLI, the Gradio app, the .bat launcher and the scheduler all
run *this*; none of them re-implements a stage. Progress, logging and
cancellation are injected so the same function can drive a progress bar or a
log file without knowing which.
"""

from __future__ import annotations

import time
import traceback
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from . import board, brief, direction as direction_mod, gate, mining, prompts, queries as queries_mod
from .apparel import prepare
from .image_provider import GenerationRequest, ImageProviderError, for_settings
from .config import Settings
from .dna import build_dna
from .llm import LLM
from .models import Concept, Reference, Role, RunResult, dump_json
from .roles import assign_roles
from .scoring import select_references
from .sources import build_sources
from .trends import derive_ladder, keywords, slugify
from .variations import build_concepts, recommend

Progress = Callable[[float, str], None]
Log = Callable[[str], None]
Cancel = Callable[[], bool]


class Cancelled(RuntimeError):
    pass


@dataclass
class PipelineOptions:
    audience: str = ""
    garment: str = "dark"
    aggressiveness: int = 5
    variants: list[str] = field(default_factory=lambda: ["A", "B", "C"])
    generate: bool = True
    generate_keys: list[str] = field(default_factory=list)  # empty -> recommended only
    include_text: bool = True
    build_mockup: bool = True
    use_llm: bool = True
    # Set by autopilot: the evidence behind an automatically chosen topic.
    discovery: dict = field(default_factory=dict)
    # Set by the house system: an audited creative route that narrows every stage.
    house_route: dict | None = None
    context_roles: list[str] = field(
        default_factory=lambda: [Role.HERO.value, Role.TEXTURE.value, Role.COMPOSITION.value, Role.TYPOGRAPHY.value]
    )

    def normalised_variants(self) -> list[str]:
        keys = [k.strip().upper()[:1] for k in self.variants if k.strip()]
        return [k for k in ("A", "B", "C") if k in keys] or ["A", "B", "C"]


# Stage weights so the progress bar advances at a believable pace.
STAGE_WEIGHTS = {
    "trend": 0.03,
    "queries": 0.05,
    "mining": 0.42,
    "select": 0.06,
    "dna": 0.06,
    "concepts": 0.08,
    "generate": 0.24,
    "output": 0.06,
}


class _Reporter:
    def __init__(self, progress: Progress | None, log: Log | None, cancel: Cancel | None, log_path: Path):
        self.progress = progress or (lambda fraction, message: None)
        self._log = log or (lambda message: None)
        self.cancel = cancel or (lambda: False)
        self.log_path = log_path
        self.base = 0.0
        self.started = time.time()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = log_path.open("a", encoding="utf-8")

    def say(self, message: str, fraction: float | None = None) -> None:
        elapsed = time.time() - self.started
        line = f"[{elapsed:7.1f}s] {message}"
        self.handle.write(line + "\n")
        self.handle.flush()
        self._log(line)
        if fraction is not None:
            self.progress(min(1.0, max(0.0, fraction)), message)

    def within(self, name: str) -> Progress:
        """A progress callback scoped to one stage's slice of the bar."""
        order = list(STAGE_WEIGHTS)
        start = sum(STAGE_WEIGHTS[k] for k in order[: order.index(name)])
        weight = STAGE_WEIGHTS[name]

        def inner(fraction: float, message: str) -> None:
            self.say(message, start + weight * max(0.0, min(1.0, fraction)))

        return inner

    def check_cancel(self) -> None:
        if self.cancel():
            raise Cancelled("run cancelled")

    def close(self) -> None:
        try:
            self.handle.close()
        except Exception:
            pass


def make_run_dir(settings: Settings, topic: str) -> tuple[Path, str]:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    slug = f"{stamp}-{slugify(topic, 40)}"
    run_dir = Path(settings.runs_dir) / settings.collection / slug
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir, slug


def run(
    topic: str,
    settings: Settings | None = None,
    options: PipelineOptions | None = None,
    *,
    progress: Progress | None = None,
    log: Log | None = None,
    cancel: Cancel | None = None,
) -> RunResult:
    """Run the whole pipeline for one topic and return the persisted result."""
    topic = (topic or "").strip()
    if not topic:
        raise ValueError("topic is required")

    settings = settings or Settings.from_env()
    options = options or PipelineOptions()
    settings.garment = options.garment or settings.garment

    run_dir, slug = make_run_dir(settings, topic)
    reporter = _Reporter(progress, log, cancel, run_dir / "run.log")
    result = RunResult(
        topic=topic,
        slug=slug,
        run_dir=str(run_dir),
        created_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        collection=settings.collection,
        settings=settings.redacted(),
        discovery=dict(options.discovery),
    )

    try:
        house = None
        if options.house_route:
            from .house.mode import HouseMode

            house = HouseMode(options.house_route)
            reporter.say(
                f"house mode: {options.house_route['product_title']} — "
                f"{options.house_route['real_subject']} / {options.house_route['mutation']}"
            )

        llm = LLM(
            settings.openai_api_key,
            model=settings.openai_model,
            base_url=settings.openai_base_url,
            reasoning_effort=settings.openai_reasoning_effort,
            enabled=options.use_llm and settings.can_use_llm,
        )

        # 1 — trend -> micro-niche ---------------------------------------
        reporter.say(f"topic: {topic}", 0.0)
        ladder = derive_ladder(
            topic, audience=options.audience, aggressiveness=options.aggressiveness,
            seed=settings.seed, llm=llm,
        )
        if house:
            ladder = house.ladder(ladder)
        result.ladder = ladder
        reporter.say(f"micro-niche: {ladder.micro_niche}", STAGE_WEIGHTS["trend"])
        reporter.check_cancel()

        # 2 — queries -----------------------------------------------------
        search_queries = (
            house.queries(count=settings.max_queries) if house
            else queries_mod.generate_queries(
                topic, ladder, count=settings.max_queries, seed=settings.seed, llm=llm
            )
        )
        result.queries = search_queries
        dump_json([q.to_dict() for q in search_queries], run_dir / "queries.json")
        reporter.say(
            f"{len(search_queries)} queries across {len(queries_mod.cluster_summary(search_queries))} clusters",
            STAGE_WEIGHTS["trend"] + STAGE_WEIGHTS["queries"],
        )
        reporter.check_cancel()

        # 3/4 — mining + analysis ----------------------------------------
        sources = build_sources(settings)
        reporter.say("sources: " + ", ".join(source.name for source in sources))
        candidates, warnings = mining.mine(
            search_queries,
            sources,
            run_dir / "references",
            per_query=settings.candidates_per_query,
            max_candidates=settings.max_candidates,
            request_delay=settings.request_delay,
            timeout=settings.http_timeout,
            user_agent=settings.user_agent,
            progress=reporter.within("mining"),
            cancel=reporter.cancel,
        )
        result.candidates = len(candidates)
        result.warnings.extend(warnings)
        reporter.check_cancel()
        if not candidates:
            raise RuntimeError(
                "no references could be mined — check connectivity on the Connection tab, "
                "or run in offline mode to use synthetic references"
            )

        # 5/6 — scoring + roles -------------------------------------------
        if house:
            selected, notes = house.select(
                candidates, select_references,
                keep=settings.keep_references, minimum=settings.min_reference_score,
            )
        else:
            selected, notes = select_references(
                candidates,
                topic_terms=keywords(topic),
                keep=settings.keep_references,
                minimum=settings.min_reference_score,
            )
        result.warnings.extend(notes)
        references: list[Reference] = house.assign(selected) if house else assign_roles(selected)
        result.references = references
        reporter.say(
            f"kept {len(references)} references — roles: "
            + ", ".join(r.role.value for r in references if r.role),
            sum(STAGE_WEIGHTS[k] for k in ("trend", "queries", "mining", "select")),
        )
        board.write_board(references, run_dir, title=f"{topic} — reference board")
        reporter.check_cancel()

        # 7/8/9 — DNA, direction, style lock ------------------------------
        dna = build_dna(
            references, ladder, garment=options.garment,
            aggressiveness=options.aggressiveness, llm=llm,
        )
        if house:
            dna = house.dna(dna)
        lock = direction_mod.load_lock(settings.runs_dir, settings.collection)
        art_direction = direction_mod.synthesise(
            ladder, dna, references, seed=settings.seed,
            aggressiveness=options.aggressiveness, lock=lock, llm=llm,
        )
        if house:
            art_direction = house.direction(art_direction)
        result.direction = art_direction
        direction_mod.save_lock(settings.runs_dir, settings.collection, art_direction)
        reporter.say(
            f"art direction: {art_direction.style_name}"
            + (" (inherited collection style lock)" if lock else " (new style lock written)"),
            sum(STAGE_WEIGHTS[k] for k in ("trend", "queries", "mining", "select", "dna")),
        )
        reporter.check_cancel()

        # 10/11 — concepts, prompts, quality gate --------------------------
        wanted = options.normalised_variants()
        concepts = [c for c in build_concepts(
            ladder, art_direction, references,
            aggressiveness=options.aggressiveness, seed=settings.seed,
        ) if c.key in wanted]
        if house:
            concepts = house.concepts(concepts)
        for concept in concepts:
            if house:
                # The house route was already audited; the gate here is the
                # structural contract that must hold before anything is paid for.
                concept.prompt = house.prompt(
                    concept, art_direction, ladder, references, garment=options.garment,
                )
                concept.negative_prompt = "; ".join(options.house_route.get("avoid", []))
                concept.gate = house.gate(concept, art_direction, ladder, references)
            else:
                gate.enforce(
                    concept, art_direction, ladder, references,
                    seed=settings.seed, garment=options.garment,
                )
                concept.prompt = prompts.build_prompt(
                    concept, art_direction, ladder, references,
                    garment=options.garment, include_text=options.include_text,
                )
            (run_dir / "prompts").mkdir(exist_ok=True)
            (run_dir / "prompts" / f"{concept.key}.txt").write_text(concept.prompt, encoding="utf-8")
            (run_dir / "prompts" / f"{concept.key}_negative.txt").write_text(
                concept.negative_prompt, encoding="utf-8"
            )
        result.concepts = concepts
        result.recommended = house.recommend(concepts) if house else recommend(concepts)
        reporter.say(
            "concepts: " + ", ".join(f"{c.key}={c.overall}" for c in concepts)
            + f" — recommended {result.recommended}",
            sum(STAGE_WEIGHTS[k] for k in ("trend", "queries", "mining", "select", "dna", "concepts")),
        )
        reporter.check_cancel()

        # 12/13 — generation + print prep ---------------------------------
        keys = [k.upper() for k in options.generate_keys] or ([result.recommended] if result.recommended else [])
        if options.generate and settings.can_generate and keys:
            provider = for_settings(settings)
            context_paths = _context_paths(references, options.context_roles)
            for index, key in enumerate(keys):
                concept = result.concept(key)
                if concept is None:
                    result.warnings.append(f"cannot generate unknown variant {key}")
                    continue
                reporter.check_cancel()
                reporter.say(f"generating {key} with {provider.name} ({len(context_paths)} context images)")
                artwork = run_dir / "artwork" / f"{key}.{settings.output_format}"
                artwork.parent.mkdir(parents=True, exist_ok=True)
                try:
                    provider.generate(GenerationRequest(
                        prompt=concept.prompt,
                        destination=artwork,
                        context_paths=[Path(path) for path in context_paths],
                        aspect_ratio=settings.aspect_ratio,
                        seed=settings.seed or None,
                        on_tick=reporter.within("generate"),
                    ))
                except ImageProviderError as exc:
                    result.warnings.append(f"generation failed for {key}: {exc}")
                    reporter.say(f"generation failed for {key}: {exc}")
                    continue
                concept.artwork_path = str(artwork)
                concept.print_assets = prepare(
                    artwork, run_dir / "print", key=key, garment=options.garment,
                    width_in=settings.print_width_in, dpi=settings.print_dpi,
                    build_mockup=options.build_mockup,
                )
                reporter.say(f"print package ready for {key}: {concept.print_assets.get('print_size_in', '')}")
        elif options.generate and not settings.can_generate:
            result.warnings.append(
                f"generation skipped — no {settings.image_credential} "
                "(prompts and print settings are still written)"
            )
            reporter.say("generation skipped: no BFL key configured")

        # 14 — brief, report, manifest ------------------------------------
        if house:
            house_brief = house.brief(references)
            for concept in concepts:
                (run_dir / f"brief_{concept.key}.md").write_text(house_brief, encoding="utf-8")
        else:
            for concept in concepts:
                brief.write_brief(result, concept)
        brief.write_report(result)
        dump_json(result, run_dir / "manifest.json")
        reporter.say(f"run complete → {run_dir}", 1.0)

    except Cancelled:
        result.warnings.append("run cancelled by user")
        reporter.say("run cancelled", 1.0)
        dump_json(result, run_dir / "manifest.json")
    except Exception as exc:
        result.warnings.append(f"run failed: {type(exc).__name__}: {exc}")
        reporter.say(f"FAILED: {type(exc).__name__}: {exc}")
        reporter.handle.write(traceback.format_exc())
        dump_json(result, run_dir / "manifest.json")
        reporter.close()
        raise
    finally:
        reporter.close()

    return result


@dataclass
class AutopilotResult:
    """One full autonomous cycle: what it found, and what it made of it."""

    report: Any = None                      # discovery.models.DiscoveryReport
    report_path: str = ""
    runs: list[RunResult] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def topics(self) -> list[str]:
        return [run_result.topic for run_result in self.runs]


def autopilot(
    settings: Settings | None = None,
    options: PipelineOptions | None = None,
    *,
    designs: int | None = None,
    progress: Progress | None = None,
    log: Log | None = None,
    cancel: Cancel | None = None,
) -> AutopilotResult:
    """Find the topics *and* make the designs — nobody types anything.

    Discovery decides what is worth printing this week; the design pipeline then
    runs on each winner with the evidence attached to its manifest, so a run can
    always answer "why this subject".
    """
    from .discovery import DiscoveryEngine  # local import keeps the base import light

    settings = settings or Settings.from_env()
    options = options or PipelineOptions()
    designs = designs or settings.autopilot_designs
    progress = progress or (lambda fraction, message: None)
    log = log or (lambda message: None)
    cancel = cancel or (lambda: False)

    llm = LLM(
        settings.openai_api_key,
        model=settings.openai_model,
        base_url=settings.openai_base_url,
        reasoning_effort=settings.openai_reasoning_effort,
        enabled=options.use_llm and settings.can_use_llm,
    )
    engine = DiscoveryEngine(settings, llm=llm, log=log)

    # Discovery owns the first third of the progress bar; the designs share the rest.
    result = AutopilotResult()
    report = engine.discover(
        count=max(designs, settings.discovery_keep),
        progress=lambda fraction, message: progress(fraction * 0.33, f"discovery: {message}"),
        cancel=cancel,
    )
    result.report = report
    result.report_path = str(engine.write_report(report))
    result.warnings.extend(report.warnings)

    picks = report.opportunities[:designs]
    if not picks:
        result.warnings.append(
            "discovery found nothing that cleared the filters — loosen the thresholds "
            "(min growth / max competition / min social) or widen the anchors"
        )
        log("autopilot: no topic cleared the filters, nothing was designed")
        progress(1.0, "no opportunities")
        return result

    for index, opportunity in enumerate(picks):
        if cancel():
            result.warnings.append("autopilot cancelled")
            break
        share = 0.67 / len(picks)
        base = 0.33 + share * index
        log(f"autopilot: designing '{opportunity.topic}' — {opportunity.summary()}")

        run_options = replace(
            options,
            audience=opportunity.audience or options.audience,
            discovery={
                "chosen_by": "autopilot",
                "score": opportunity.overall,
                "scores": opportunity.scores.to_dict(),
                "growth_3m": opportunity.growth_3m,
                "momentum": opportunity.momentum,
                "social_heat": opportunity.social_heat,
                "avg_engagement": opportunity.avg_engagement,
                "competition": opportunity.competition,
                "sources": opportunity.sources,
                "family": opportunity.family,
                "correlated_with": opportunity.correlated_with,
                "rising_queries": opportunity.rising_queries[:8],
                "angle": opportunity.angle,
                "durability": opportunity.durability,
                "risk": opportunity.risk,
                "signals": [signal.to_dict() for signal in opportunity.signals],
                "report": result.report_path,
            },
        )
        try:
            run_result = run(
                opportunity.topic,
                settings,
                run_options,
                progress=lambda fraction, message: progress(base + share * fraction, message),
                log=log,
                cancel=cancel,
            )
            result.runs.append(run_result)
        except Exception as exc:
            message = f"design failed for '{opportunity.topic}': {type(exc).__name__}: {exc}"
            result.warnings.append(message)
            log(message)

    progress(1.0, f"autopilot complete — {len(result.runs)} design run(s)")
    return result


def _context_paths(references: list[Reference], role_names: list[str]) -> list[Path]:
    wanted = [name.upper() for name in role_names]
    ordered: list[Path] = []
    for name in wanted:
        for reference in references:
            if reference.role and reference.role.value == name and reference.local_path:
                ordered.append(Path(reference.local_path))
                break
    if not ordered:
        ordered = [Path(r.local_path) for r in references[:3] if r.local_path]
    return ordered[:4]


def regenerate(
    result: RunResult,
    key: str,
    settings: Settings,
    options: PipelineOptions,
    *,
    seed: int | None = None,
    progress: Progress | None = None,
    log: Log | None = None,
) -> Concept:
    """Re-render one variant of an existing run without re-mining references."""
    concept = result.concept(key)
    if concept is None:
        raise ValueError(f"unknown variant {key}")
    if not settings.can_generate:
        raise ImageProviderError(f"{settings.image_credential} is not set")

    run_dir = Path(result.run_dir)
    reporter = _Reporter(progress, log, None, run_dir / "run.log")
    try:
        provider = for_settings(settings)
        stamp = datetime.now(timezone.utc).strftime("%H%M%S")
        artwork = run_dir / "artwork" / f"{key}-{stamp}.{settings.output_format}"
        artwork.parent.mkdir(parents=True, exist_ok=True)
        reporter.say(f"regenerating {key}")
        provider.generate(GenerationRequest(
            prompt=concept.prompt,
            destination=artwork,
            context_paths=[Path(path) for path in _context_paths(result.references, options.context_roles)],
            aspect_ratio=settings.aspect_ratio,
            seed=seed,
            on_tick=lambda fraction, message: reporter.say(message, fraction),
        ))
        concept.artwork_path = str(artwork)
        concept.print_assets = prepare(
            artwork, run_dir / "print", key=f"{key}-{stamp}", garment=options.garment,
            width_in=settings.print_width_in, dpi=settings.print_dpi, build_mockup=options.build_mockup,
        )
        brief.write_report(result)
        dump_json(result, run_dir / "manifest.json")
        reporter.say("regeneration complete", 1.0)
    finally:
        reporter.close()
    return concept
